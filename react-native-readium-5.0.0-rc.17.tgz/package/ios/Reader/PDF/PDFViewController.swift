import UIKit
import ReadiumShared
import ReadiumNavigator

class PDFViewController: ReaderViewController {

    init(
        publication: Publication,
        locator: ReadiumShared.Locator?,
        bookId: String
    ) throws {
        let navigator = try PDFNavigatorViewController(
            publication: publication,
            initialLocation: locator,
            httpServer: EPUBHTTPServer.shared
        )

        super.init(
            navigator: navigator,
            publication: publication,
            bookId: bookId
        )

        navigator.delegate = self
    }

    var pdfNavigator: PDFNavigatorViewController {
        return navigator as! PDFNavigatorViewController
    }

}

extension PDFViewController: PDFNavigatorDelegate {}
