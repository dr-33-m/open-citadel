package com.reactnativereadium.reader

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.commitNow
import androidx.lifecycle.ViewModelProvider
import com.reactnativereadium.R
import org.readium.adapter.pdfium.navigator.PdfiumEngineProvider
import org.readium.adapter.pdfium.navigator.PdfiumPreferences
import org.readium.r2.navigator.Navigator
import org.readium.r2.navigator.pdf.PdfNavigatorFragment
import org.readium.r2.shared.ExperimentalReadiumApi
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.Publication

@OptIn(ExperimentalReadiumApi::class)
class PdfReaderFragment : VisualReaderFragment() {

    override lateinit var model: ReaderViewModel
    override lateinit var navigator: Navigator
    private lateinit var publication: Publication
    private lateinit var factory: ReaderViewModel.Factory
    private lateinit var pdfEngineProvider: PdfiumEngineProvider

    fun initFactory(
        publication: Publication,
        initialLocation: Locator?
    ) {
        factory = ReaderViewModel.Factory(
            publication,
            initialLocation
        )
        pdfEngineProvider = PdfiumEngineProvider()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        check(::pdfEngineProvider.isInitialized) { "PdfReaderFragment factory was not initialized" }

        ViewModelProvider(this, factory)
            .get(ReaderViewModel::class.java)
            .let {
                model = it
                publication = it.publication
            }

        childFragmentManager.fragmentFactory =
            PdfNavigatorFragment.createFactory(
                publication = publication,
                initialLocator = model.initialLocation,
                preferences = PdfiumPreferences(),
                pdfEngineProvider = pdfEngineProvider
            )

        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = super.onCreateView(inflater, container, savedInstanceState)
        val navigatorFragmentTag = getString(R.string.pdf_navigator_tag)

        if (savedInstanceState == null) {
            childFragmentManager.commitNow {
                add(
                    R.id.fragment_reader_container,
                    PdfNavigatorFragment::class.java,
                    Bundle(),
                    navigatorFragmentTag
                )
            }
        }

        navigator = childFragmentManager.findFragmentByTag(navigatorFragmentTag) as Navigator

        return view
    }

    companion object {
        fun newInstance(): PdfReaderFragment {
            return PdfReaderFragment()
        }
    }
}
